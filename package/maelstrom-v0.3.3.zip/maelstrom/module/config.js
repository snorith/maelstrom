export const MAELSTROM = {
    attributes: [
        "attack",
        "missile",
        "defence",
        "knowledge",
        "will",
        "endurance",
        "persuasion",
        "perception",
        "speed",
        "agility"
    ],
    physicalAttributes: [
        "attack",
        "missile",
        "defence",
        "speed",
        "agility"
    ],
    initiativeAttribute: "speed"
};
